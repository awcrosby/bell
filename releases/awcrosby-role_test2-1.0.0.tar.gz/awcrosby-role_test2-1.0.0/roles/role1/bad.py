my_var =   "bad_spacing"
my_var2 = "trailing whitespace"      
