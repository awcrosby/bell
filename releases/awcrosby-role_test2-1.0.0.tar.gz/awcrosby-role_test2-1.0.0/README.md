test README for roletest2 collection
